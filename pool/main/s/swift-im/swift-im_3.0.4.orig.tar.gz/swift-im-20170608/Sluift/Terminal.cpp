/*
 * Copyright (c) 2013 Isode Limited.
 * All rights reserved.
 * See the COPYING file for more information.
 */

#include <Sluift/Terminal.h>

using namespace Swift;

Terminal::Terminal() : completer(NULL) {
}

Terminal::~Terminal() {
}
