/*
 * Copyright (c) 2013 Isode Limited.
 * All rights reserved.
 * See the COPYING file for more information.
 */

#pragma once

#include <Sluift/SluiftGlobals.h>

namespace Swift {
	namespace Sluift {
		extern SluiftGlobals globals;
	}
}
