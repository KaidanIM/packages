/*
 * Copyright (c) 2013 Isode Limited.
 * All rights reserved.
 * See the COPYING file for more information.
 */

#include <Sluift/Completer.h>

using namespace Swift;

Completer::~Completer() {
}
