/*
 * Copyright (c) 2013 Isode Limited.
 * All rights reserved.
 * See the COPYING file for more information.
 */

#include <Sluift/LuaElementConvertor.h>

using namespace Swift;

LuaElementConvertor::~LuaElementConvertor() {
}

boost::optional<std::string> LuaElementConvertor::NO_RESULT;
