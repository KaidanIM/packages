/*
 * Copyright (c) 2010 Isode Limited.
 * All rights reserved.
 * See the COPYING file for more information.
 */

#include "Swift/QtUI/EventViewer/EventView.h"

namespace Swift {
EventView::EventView(QWidget* parent) : QListView(parent) {
	
}

}
