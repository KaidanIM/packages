/*
 * Copyright (c) 2010 Isode Limited.
 * All rights reserved.
 * See the COPYING file for more information.
 */

#include <SwifTools/Idle/IdleDetector.h>

namespace Swift {

IdleDetector::~IdleDetector() {
}

}
