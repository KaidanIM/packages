/*
 * Copyright (c) 2011 Isode Limited.
 * All rights reserved.
 * See the COPYING file for more information.
 */

#include <SwifTools/URIHandler/URIHandler.h>

using namespace Swift;

URIHandler::URIHandler() {
}

URIHandler::~URIHandler() {
}
