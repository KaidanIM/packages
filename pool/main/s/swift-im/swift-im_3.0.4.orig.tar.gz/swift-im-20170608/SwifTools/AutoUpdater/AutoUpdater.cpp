/*
 * Copyright (c) 2010 Isode Limited.
 * All rights reserved.
 * See the COPYING file for more information.
 */

#include <SwifTools/AutoUpdater/AutoUpdater.h>

namespace Swift {

AutoUpdater::~AutoUpdater() {
}

}
